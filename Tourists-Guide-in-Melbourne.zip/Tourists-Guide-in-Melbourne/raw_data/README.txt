melbourne_city_landmarks.csv ---- Melbourne landmarks coordinates, street and description（https://github.com/statelibraryvic/opendata/blob/master/melbourne_city_landmarks.csv）

bike-share-dock-locations.csv ---- Melbourne bike dock locations, payment methods (https://discover.data.vic.gov.au/dataset/bike-share-dock-locations)

bus-stops-for-melbourne-visitor-shuttle ---- Melbourne bus stops locations and address （https://discover.data.vic.gov.au/dataset/bus-stops-for-melbourne-visitor-shuttle）

melbourne_and_metropolitan_hotels_pubs_and_publicans(new) - https://discover.data.vic.gov.au/dataset/melbourne-and-metropolitan-hotels-pubs-and-publicans

residential-dwellings.csv - https://data.melbourne.vic.gov.au/explore/dataset/residential-dwellings/export/

coworking-spaces.csv - https://data.melbourne.vic.gov.au/explore/dataset/coworking-spaces/export/

tram-tracks.geojson - https://data.melbourne.vic.gov.au/explore/dataset/tram-tracks/export/?location=12,-37.81397,144.95275&basemap=mbs-7a7333

pedestrian-network.json - https://data.melbourne.vic.gov.au/explore/dataset/pedestrian-network/export/?location=16,-37.81111,144.95343&basemap=mbs-7a7333
